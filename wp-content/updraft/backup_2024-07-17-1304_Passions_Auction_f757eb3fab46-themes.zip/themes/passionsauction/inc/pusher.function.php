<?php
  // require_once 'pusher/vendor/autoload.php';
  // $options = array(
  //   'cluster' => 'ap2',
  //   'useTLS' => true
  // );
  // $pusher = new Pusher\Pusher(
  //   'e4bbf991aaac16fd100c',
  //   '90a7ef5aaf8097720dba',
  //   '1761377',
  //   $options
  // );

  // $data['message'] = 'hello world';
  // $pusher->trigger('auction', 'newbid', $data);
?>