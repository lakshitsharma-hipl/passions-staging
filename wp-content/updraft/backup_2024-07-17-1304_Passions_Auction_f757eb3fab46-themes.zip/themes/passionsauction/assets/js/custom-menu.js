/*jQuery(document).ready(function($) {
    if (userLoginStatus === 'loggedin') {
        $('.login-menu-item, .signup-menu-item').hide();
        $('.dashboard-menu-item').show();
    } else {
        $('.dashboard-menu-item').hide();
        $('.login-menu-item, .signup-menu-item').show();
    }
});
*/